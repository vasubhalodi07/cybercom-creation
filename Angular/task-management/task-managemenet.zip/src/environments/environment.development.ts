export const environment = {
  baseUrl: 'https://api.escuelajs.co/',
  userUrl: 'api/v1/users',
};
