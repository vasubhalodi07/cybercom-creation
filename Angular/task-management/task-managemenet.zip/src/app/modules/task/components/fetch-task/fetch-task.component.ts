import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-fetch-task',
  templateUrl: './fetch-task.component.html',
  styleUrls: ['./fetch-task.component.css'],
})
export class FetchTaskComponent implements OnInit {
  displayedColumns: string[] = [
    'title',
    'description',
    'dueDate',
    'priority',
    'assignedTo',
    'actions',
  ];
  taskForms: FormGroup[] = [];
  newTask: any = {};
  fetchTasks: any[] = [];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.fetchTasks = [];
    this.fetchTasks.forEach((task) => {
      this.taskForms.push(this.createTaskForm(task));
    });
  }

  createTaskForm(task: any): FormGroup {
    return this.fb.group({
      title: [task.title, Validators.required],
      description: [task.description, Validators.required],
      dueDate: [task.dueDate, Validators.required],
      priority: [task.priority, Validators.required],
      assignedTo: [task.assignedTo, Validators.required],
    });
  }

  toggleAddTask(): void {
    this.newTask = {};
    this.taskForms.push(this.createTaskForm(this.newTask));
  }

  saveTask(index: number): void {
    if (this.taskForms[index].valid) {
      const newTask = this.taskForms[index].value;
      if (this.isAddingNewTask(index)) {
        this.fetchTasks.push(newTask);
      } else {
        this.fetchTasks[index] = newTask;
      }
      this.taskForms.pop();
    } else {
      console.log('Form is invalid. Cannot save task.');
    }
  }

  cancelTask(index: number): void {
    if (this.isAddingNewTask(index)) {
      this.taskForms.pop();
    } else {
      // Revert changs for existing task (optional)
    }
  }

  isAddingNewTask(index: number): boolean {
    return this.taskForms.length - 1 === index;
  }
}
