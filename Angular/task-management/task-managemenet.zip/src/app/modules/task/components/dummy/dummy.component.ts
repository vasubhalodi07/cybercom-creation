import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from '../../../../core/services/user.service';

interface Task {
  title: string;
  description: string;
  isNew: boolean;
  taskForm: FormGroup;
}

@Component({
  selector: 'app-dummy',
  templateUrl: './dummy.component.html',
  styleUrls: ['./dummy.component.css'],
})
export class DummyComponent implements OnInit {
  fetchTasks: MatTableDataSource<Task>;
  displayedColumns: string[] = [
    'title',
    'description',
    'dueDate',
    'priority',
    'assignedTo',
    'actions',
  ];
  displayedPriority: string[] = ['Low', 'Medium', 'High'];
  fetchUsers: any;

  constructor(private fb: FormBuilder, private userService: UserService) {
    this.fetchTasks = new MatTableDataSource<Task>([]);
    this.loadTasksFromLocalStorage();
    // this.addEmptyTask();
  }

  ngOnInit(): void {
    this.fetchUsersRecords();
  }

  fetchUsersRecords() {
    this.userService.fetchUser().subscribe({
      next: (res) => {
        this.fetchUsers = res;
      },
      error: (err) => {
        console.log(err);
      },
    });
  }

  loadTasksFromLocalStorage() {
    const tasks = JSON.parse(localStorage.getItem('task')!) || [];
    const taskArray: Task[] = tasks.map((task: any) => ({
      id: task.id,
      title: task.title,
      description: task.description,
      dueDate: task.dueDate,
      priority: task.priority,
      assignedTo: task.assignedTo,
    }));
    this.fetchTasks.data = taskArray;
  }

  // addEmptyTask() {
  //   const emptyTask: Task = {
  //     title: '',
  //     description: '',
  //     isNew: true,
  //     taskForm: this.fb.group({
  //       title: ['', Validators.required],
  //       description: ['', Validators.required],
  //       dueDate: ['', Validators.required],
  //       priority: ['', Validators.required],
  //       assignedTo: ['', Validators.required],
  //     }),
  //   };
  //   this.fetchTasks.data.push(emptyTask);
  //   this.fetchTasks._updateChangeSubscription();
  // }

  addTask() {
    this.fetchTasks.data.push({
      title: '',
      description: '',
      isNew: true,
      taskForm: this.fb.group({
        title: ['', Validators.required],
        description: ['', Validators.required],
        dueDate: ['', Validators.required],
        priority: ['', Validators.required],
        assignedTo: ['', Validators.required],
      }),
    });
    this.fetchTasks._updateChangeSubscription();
  }

  saveNewTask(index: number) {
    const task = this.fetchTasks.data[index];
    console.log(task.taskForm.value);
  }

  saveTasks(task: any) {
    let fetchTasks = JSON.parse(localStorage.getItem('task')!) || [];
    let data = task.taskForm.value;
    let object = {
      id: new Date(),
      title: data.title,
      description: data.description,
      dueDate: data.dueDate,
      priority: data.priority,
      assignedTo: data.assignedTo,
    };

    let mergeTasks = [...fetchTasks, object];

    console.log(mergeTasks);
    // localStorage.setItem('task', JSON.stringify(mergeTasks));
  }

  saveTask(index: number) {
    const task = this.fetchTasks.data[index];
    if (task.taskForm.valid) {
      const { title, description } = task.taskForm.value;
      task.title = title;
      task.description = description;
    }
  }

  deleteTask(index: number) {
    this.fetchTasks.data.splice(index, 1);
    this.fetchTasks._updateChangeSubscription();
  }

  cancelTask(index: number) {
    this.fetchTasks.data.splice(index, 1);
    this.fetchTasks._updateChangeSubscription();
  }
}
